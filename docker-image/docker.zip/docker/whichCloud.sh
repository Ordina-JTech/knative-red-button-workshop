#!/usr/bin/env bash

echo "Setting up cloud: ${CLOUD}"
if [ "${CLOUD}" == "azure" ]
then
  kubectl config use-context azure-kubernetes-cluster-admin
elif [ "${CLOUD}" == "aws" ]
then
  kubectl config use-context aws
elif [ "${CLOUD}" == "gcloud" ]
then
  # maybe change cluster name? currently it's using my-cluster as name and not google
  kubectl config use-context my-cluster
else
  echo "Unrecognized cloud configuration: ${CLOUD}. Please use one of the following arguments: azure, aws or gcloud"
  exit 1
fi
echo "Finished setting configuration for cloud: ${CLOUD}"
exit 0