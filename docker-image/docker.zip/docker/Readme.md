# Docker Image
To ease the pain of setting up the environment to work with one of the clouds (Azure, AWS or Google)
we created a docker image that can be used to communicate with a prebuilt kubernetes cluster.

## Build Docker image
To build the docker image run the following command:
```
docker build -t red-button-bridge .
```
This will update the docker base image, install needed packages, install cloud specific cli's 
and prepare kubernetes configuration files.

## Save the Docker container to a gzip file
In order to be able to load the docker image for the participants we choose to zip the docker container and load this zip in the next step. So first create a zip file with the following command (note: the previous step to build the Docker image should already have been performed):
```
docker save red-button-bridge | gzip > red-button-bridge.tgz
```
Now copy this gzip to the repository used by the workshop-participants.

Loading is not necessary here because you build it on this pc so it is already present, so you can skip to the next task. However the participants need to load it before they can start. They should use the following command (also present in their instructions):
```
docker load < red-button-bridge.tgz
``` 

## Run Docker Image
To run our prebuilt image and connect it to one of the clouds one must execute the following command:
```
# CLOUD should be one of: azure, aws or gcloud, any other value should fail
# The volume mapping points to a location containing the scripts you want to launch
docker run -it -e CLOUD="gcloud" --name rb-button -p 9097:9097 -p 3000:3000 -v "$(pwd)/volume-docker":/volume-docker red-button-bridge
```
```
# For Windows with GitBash you might instead need to run this command to start the docker container
winpty docker.exe run -it -e CLOUD="gcloud" --name rb-button -p 9097:9097 -p 3000:3000 -v /$(pwd)/volume-docker:/volume-docker red-button-bridge
```

A container will spin up and provide us with a bash prompt in which we can start talking to one of the 
Kubernetes clusters, using `kubectl` or `kn` commands. As an example, we also exposed port 9097 and 3000 so that
it is possible to connect to one of the dashboards like: Kubernetes dashboard/Tekton dashboard etc.

## Accesing Tekton Dashboard and Knative Monitoring via Docker Container
Accessing the Tekton dashboard or the Knative Monitoring is not much different than what we are used to. Just fire up the container
as explained above and then fire up the following commands:
```
# adding --address makes it possible to listen from all addresses instead of localhost only
kubectl port-forward -n tekton-pipelines --address 0.0.0.0 svc/tekton-dashboard 9097:9097 
kubectl port-forward -n knative-monitoring --address 0.0.0.0 \
$(kubectl get pods -n knative-monitoring --selector=app=grafana --output=jsonpath="{.items..metadata.name}") \
3000
```
The same applies to any other dashboard you wish to expose, may it be Kinabana/Kubernetes etc.